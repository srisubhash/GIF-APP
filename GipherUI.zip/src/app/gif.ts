export class Gif{
    id:String;
    userid:String;
    url:String;
    
}