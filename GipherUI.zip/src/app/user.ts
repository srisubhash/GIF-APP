export class User{
    fullname: String;
    userid:String;
    password:String;
    constructor(
        
       // image:File

    ){

    }
}